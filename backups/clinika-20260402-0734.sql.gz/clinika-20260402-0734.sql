--
-- PostgreSQL database dump
--

\restrict Gr7vUXySSHTLxJxYSplZ5LIAI8PE5njkH5yJrCYa0nYhYzy4zieAUxrUQSu319f

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: bonusstatus; Type: TYPE; Schema: public; Owner: clinika
--

CREATE TYPE public.bonusstatus AS ENUM (
    'PENDING',
    'PAID'
);


ALTER TYPE public.bonusstatus OWNER TO clinika;

--
-- Name: bonustype; Type: TYPE; Schema: public; Owner: clinika
--

CREATE TYPE public.bonustype AS ENUM (
    'regular',
    'commission'
);


ALTER TYPE public.bonustype OWNER TO clinika;

--
-- Name: referralstatus; Type: TYPE; Schema: public; Owner: clinika
--

CREATE TYPE public.referralstatus AS ENUM (
    'created',
    'confirmed',
    'expired',
    'cancel_requested',
    'cancelled'
);


ALTER TYPE public.referralstatus OWNER TO clinika;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: clinika
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'MANAGER',
    'partner'
);


ALTER TYPE public.userrole OWNER TO clinika;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.activity_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    user_name character varying(200),
    action character varying(200) NOT NULL,
    entity_type character varying(50),
    entity_id uuid,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.activity_log OWNER TO clinika;

--
-- Name: bonuses; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.bonuses (
    id uuid NOT NULL,
    admin_id uuid NOT NULL,
    referral_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    status public.bonusstatus NOT NULL,
    created_at timestamp without time zone NOT NULL,
    paid_at timestamp without time zone,
    bonus_type public.bonustype DEFAULT 'regular'::public.bonustype NOT NULL
);


ALTER TABLE public.bonuses OWNER TO clinika;

--
-- Name: clinic_schedules; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.clinic_schedules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    day_of_week integer NOT NULL,
    open_time character varying(5) DEFAULT '09:00'::character varying NOT NULL,
    close_time character varying(5) DEFAULT '18:00'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    CONSTRAINT clinic_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6)))
);


ALTER TABLE public.clinic_schedules OWNER TO clinika;

--
-- Name: clinics; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.clinics (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(500),
    phone character varying(20),
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.clinics OWNER TO clinika;

--
-- Name: kpi_targets; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.kpi_targets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid NOT NULL,
    month date NOT NULL,
    target_referrals integer DEFAULT 0 NOT NULL,
    target_confirmed integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.kpi_targets OWNER TO clinika;

--
-- Name: referral_comments; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.referral_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    referral_id uuid NOT NULL,
    author_id uuid NOT NULL,
    text text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.referral_comments OWNER TO clinika;

--
-- Name: referrals; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.referrals (
    id uuid NOT NULL,
    from_clinic_id uuid,
    to_clinic_id uuid NOT NULL,
    service_id uuid NOT NULL,
    patient_phone character varying(20) NOT NULL,
    created_by_admin_id uuid NOT NULL,
    confirmed_by_admin_id uuid,
    status public.referralstatus NOT NULL,
    qr_code text,
    notes character varying(500),
    created_at timestamp without time zone NOT NULL,
    confirmed_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL,
    cancel_reason character varying(500),
    cancel_requested_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    cancelled_by_id uuid,
    appointment_at timestamp without time zone
);


ALTER TABLE public.referrals OWNER TO clinika;

--
-- Name: services; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.services (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(50) NOT NULL,
    bonus_amount numeric(10,2) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    clinic_id uuid
);


ALTER TABLE public.services OWNER TO clinika;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.system_settings (
    key character varying(100) NOT NULL,
    value character varying(500) NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO clinika;

--
-- Name: users; Type: TABLE; Schema: public; Owner: clinika
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    telegram_id character varying(50),
    full_name character varying(200) NOT NULL,
    phone_number character varying(20),
    date_of_birth character varying(20),
    role public.userrole NOT NULL,
    clinic_id uuid,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    username character varying(100),
    password_hash character varying(200),
    category character varying(30)
);


ALTER TABLE public.users OWNER TO clinika;

--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.activity_log (id, user_id, user_name, action, entity_type, entity_id, created_at) FROM stdin;
04584297-ffb0-4058-ba87-1c7ac4e09aa5	7192f426-cf48-402a-bf07-1df31e7c255f	Доулбиева Линда Сохруевна	Создано направление	referral	ad97644c-3ff6-4bef-8703-801ee8311f1e	2026-04-01 12:09:34.583747
d07038df-6536-4dd2-9096-5b904e9b8d3c	7192f426-cf48-402a-bf07-1df31e7c255f	Доулбиева Линда Сохруевна	Создано направление	referral	9cd5fd52-d088-44d5-a388-f8791b42842b	2026-04-01 12:48:45.53428
\.


--
-- Data for Name: bonuses; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.bonuses (id, admin_id, referral_id, amount, status, created_at, paid_at, bonus_type) FROM stdin;
8fce6dd4-34e5-400a-8cb1-518eb0a33c41	539e674d-584a-4279-9d35-74d40860916f	a4f91d90-2b7f-4444-ba4c-8229485e325f	500.00	PAID	2026-03-31 17:17:27.701273	2026-04-01 02:06:46.625875	regular
b0bb814c-93ef-415c-96ad-0a0bb8821d9f	539e674d-584a-4279-9d35-74d40860916f	f9202e3e-65e5-4e56-a8cb-726b26652fd1	270.00	PAID	2026-03-31 17:52:38.257717	2026-04-01 02:06:46.625875	regular
ebcb154e-4c3e-4023-9db9-a398040b4105	539e674d-584a-4279-9d35-74d40860916f	591febe6-a663-4370-b5bf-1a670947afb2	300.00	PAID	2026-03-31 17:14:08.027029	2026-04-01 02:06:46.625875	regular
278f8b83-3107-4984-b5a9-ac78ad04382b	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	4e816b5d-5988-4927-be03-b4df8e5ef3f7	450.00	PAID	2026-03-31 17:50:49.173328	2026-04-01 02:06:47.424525	regular
b2e7f45c-9bb1-449a-ae78-3d163ed045ad	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	c1aee370-4566-401a-a9f7-2c09d40c9e8f	450.00	PAID	2026-03-31 17:51:48.271435	2026-04-01 02:06:47.424525	regular
0c52d906-bdad-48e4-8f69-11c7ba3756d8	e4d68891-5966-42cf-9547-5b72c2c61e05	f9202e3e-65e5-4e56-a8cb-726b26652fd1	30.00	PAID	2026-03-31 17:52:38.257723	2026-04-01 02:06:48.064378	commission
4295d2d0-3fd5-402b-b949-b9043414135e	e4d68891-5966-42cf-9547-5b72c2c61e05	8677fc3f-5562-4fcf-b7f0-146db4084810	300.00	PAID	2026-03-31 17:13:29.862008	2026-04-01 02:06:48.064378	regular
4888649a-f9be-466b-83b3-e9a319eeb75f	e4d68891-5966-42cf-9547-5b72c2c61e05	c1aee370-4566-401a-a9f7-2c09d40c9e8f	50.00	PAID	2026-03-31 17:51:48.271441	2026-04-01 02:06:48.064378	commission
76fdc68e-be30-4e0b-8dc0-33c19c4e58b2	e4d68891-5966-42cf-9547-5b72c2c61e05	4e816b5d-5988-4927-be03-b4df8e5ef3f7	50.00	PAID	2026-03-31 17:50:49.173337	2026-04-01 02:06:48.064378	commission
\.


--
-- Data for Name: clinic_schedules; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.clinic_schedules (id, clinic_id, day_of_week, open_time, close_time, is_active) FROM stdin;
9ecd1220-2934-466c-bc78-832c9e140b19	6dfa30fb-50d8-492e-ad78-c785949b7e2d	0	09:00	18:00	t
7738a4bd-62c4-46db-bae5-1c008a64b7ec	6dfa30fb-50d8-492e-ad78-c785949b7e2d	1	09:00	18:00	t
399fa187-7bce-430a-9f74-e7bbeee58815	6dfa30fb-50d8-492e-ad78-c785949b7e2d	2	09:00	18:00	t
d2fd5d2e-7f16-47d8-9003-03e11670fa37	6dfa30fb-50d8-492e-ad78-c785949b7e2d	3	09:00	18:00	t
0cb912a0-6995-4330-8c2f-375e4ed7fbf9	6dfa30fb-50d8-492e-ad78-c785949b7e2d	4	09:00	17:00	t
5b5a5761-e33b-4566-9805-e59aa6aa62a5	6dfa30fb-50d8-492e-ad78-c785949b7e2d	5	09:00	14:00	t
2dcd1cf7-8480-49cf-a9a6-b8c623d6e82c	6dfa30fb-50d8-492e-ad78-c785949b7e2d	6	09:00	14:00	t
693f5c4c-7897-4385-9c38-4506836e0134	106a34ff-4704-406c-9912-3b407e5417b0	0	09:00	18:00	t
89af5858-7612-44b6-bcfe-e3eef533e289	106a34ff-4704-406c-9912-3b407e5417b0	1	09:00	18:00	t
80fae3e8-0201-454d-b4a3-f91dac918e41	106a34ff-4704-406c-9912-3b407e5417b0	2	09:00	18:00	t
de4746da-0167-4293-84b8-264bee189b0d	106a34ff-4704-406c-9912-3b407e5417b0	3	09:00	18:00	t
ca3c495a-571d-4e3d-aafe-b4681a5cea8f	106a34ff-4704-406c-9912-3b407e5417b0	4	09:00	18:00	t
e35b5016-87c1-4357-b459-073665497073	106a34ff-4704-406c-9912-3b407e5417b0	5	09:00	18:00	f
764c1f58-7344-4c6e-9cd5-fb86d5a503f8	106a34ff-4704-406c-9912-3b407e5417b0	6	09:00	18:00	f
\.


--
-- Data for Name: clinics; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.clinics (id, name, address, phone, is_active, created_at) FROM stdin;
6dfa30fb-50d8-492e-ad78-c785949b7e2d	СклифЛаб-Грозный	ул. Лорсанова, 9 "А"	+7 (995)808-88-77	t	2026-03-31 02:23:49.565162
106a34ff-4704-406c-9912-3b407e5417b0	АРЦ	ул. им. Миллионщикова, 76	+7 (928)085-88-77	t	2026-03-31 02:23:49.565169
5680937f-a565-4398-8cc4-9b17a7b54f06	НЕОМЕД	ул. им. Шейха Али Митаева, 50	+7 (929)897-27-91	t	2026-03-31 02:23:49.565172
\.


--
-- Data for Name: kpi_targets; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.kpi_targets (id, admin_id, month, target_referrals, target_confirmed) FROM stdin;
574b0382-077a-41f4-a363-1c29eb0b1dfa	539e674d-584a-4279-9d35-74d40860916f	2026-03-01	20	15
299cb772-510c-42af-bd76-2a096db1b1c5	539e674d-584a-4279-9d35-74d40860916f	2026-04-01	0	0
\.


--
-- Data for Name: referral_comments; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.referral_comments (id, referral_id, author_id, text, created_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.referrals (id, from_clinic_id, to_clinic_id, service_id, patient_phone, created_by_admin_id, confirmed_by_admin_id, status, qr_code, notes, created_at, confirmed_at, expires_at, cancel_reason, cancel_requested_at, cancelled_at, cancelled_by_id, appointment_at) FROM stdin;
75c87eea-81b1-459e-b5d6-9b50611ffbac	6dfa30fb-50d8-492e-ad78-c785949b7e2d	6dfa30fb-50d8-492e-ad78-c785949b7e2d	639104c6-8900-4de6-893c-3c537f738195	+79280037547	539e674d-584a-4279-9d35-74d40860916f	\N	cancelled	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADGElEQVR4nO2cQW6jQBBFXw1IXoKUA/gozQ3mSFGOlBvAUXKAkZplJNCfRXcDTlaZZMDCxcKCtp9ULX/V76pu28SXr+HX1xlwyCGHHHLIIYfOCVm+aqwba6wDrBvL8ObukPAc2h8KkqQIwGzqxxqgkvpmyneSdAvtF55D+0NjTgB6uU4wtADMRni7JB2YWX1ceA7tBtUfni28XWRBoOE61Rb6dxPjUeE5tDv0UREa2goBGA0wWPW5Y3Hnc3LoJ6BGUp/u3s26ZBg1hJg/IGk6LjyH9oYGMzNrwZ7fLoLxIiCnB+uYU6lxVHgO7e0aW2NIxcVsDG1VHptb57jzOTn0HYhUVYYI6skvBE2ob5QShRRLHRokqb/zOTn0HSgpIolBmpAiqE86KAKBVSquiEeBKlk3XmTWAjQTZm0lgqa0vLRn71A9BFRcQ2m5oNy9XFqYy2NaUXiOOD1E+bolQqxyCRpilWuNsIohLhZz53Ny6PuQFGcrZUYlhnYZG3NTQi9XybpDwnPoCNdQLimkabvxtWQL9U0xEM8RZ4aKETRK9eW26khFSFaJFLOJuCJODW1yRM4HTW5FrNVnFoMr4iGgm55l825AJQOD0OdhC6+zMVx9X+MRoKQIg2qC8UkW+rnW8PtPXVQSYZGM9g7Pod2hTT8ita3D2ogqS4jVSdw1zg8t/YjSwF5XkfmqtO6Ve61xfmjZ6cpffBoMMb+UfY2yzeGKOD2ENlekiGGtPpeuVZB3sR8B2u599h+sY+1CREjW4Tni9NCNa6xnIbjd1wByy8IVcXboxjU2VcdUDkREWGXhOeL80NKPAFJTIj1elMaG61TD+DQRXtv9w3PoKCgsK8uhraS+ebfiJFA2RY8Lz6H9oeU3XT1gzzHLIlnHUI5hW3dQeA7tBn36TRfNnBrYFl6fRIgzgrnWcFVxlzufk0M/CoVISQrpsCVYtxyb6Y8Oz6H/DZUc0QgYQYwtFgQMVk1ivMhoptpCDxb6fcNzaHcoK2JIflBhNMIYW4DZNHQVSu+OT5PvfZ4fMv9nMocccsghhxxy6B+hv/ZFeQeDc0ufAAAAAElFTkSuQmCC		2026-03-31 17:06:37.570139	\N	2026-04-07 17:06:37.570147	перепутал услугу.	2026-03-31 17:25:56.113934	2026-03-31 17:26:40.904957	7192f426-cf48-402a-bf07-1df31e7c255f	\N
8677fc3f-5562-4fcf-b7f0-146db4084810	6dfa30fb-50d8-492e-ad78-c785949b7e2d	106a34ff-4704-406c-9912-3b407e5417b0	2e56c1be-9aed-4c80-ba33-a7426fac672e	+79001234567	e4d68891-5966-42cf-9547-5b72c2c61e05	e4d68891-5966-42cf-9547-5b72c2c61e05	confirmed	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADAklEQVR4nO2cTW7bMBCFvykFeEkBPkCOQt+gRwpypNxAOkoOUIBcFqAwXZCUabebxK7tWKOFob8PJqHJE/n4HFE+vc0/Ps+AQQYZZJBBBhn0nJDUbYB5XATSAKR2+nDcu0vzDLohhKqqElRVNTpVjUDQDOCUUM457e6bHrxPBl0DSlUA5OAzOqUB1biIvr3kckNRkHs1z6A7QmlADj7DPDqV17i0d8XVv8mgR4SGf59OIxJ0EZ0FlHSFbzLoe0CtIrxCefBlz2XmMSrgsoR36J2sB++TQZdAtSJmAcABaV9KQMLHkCXEPcAi92meQTeHSkV0AjCPDoUMsAjziOipQjx8nwy6BGqzzwiAU51wqpNXLYdnV9Vmn88OUZ9ydKqTz8WKqGVxet8EmB/x/FDViLIXAXw9rOZU86UwjdgSpBqdgs8Q4iJFLWAp1rW+jVUj5HCX5hl0B43wuWkEFHkoahFWjVglwzTiqaH1rVFLoG25iMLJh1XEFqCuIk40gjaKxHUKYhXx/ND61mjiMHnV9vTrAmidZkRna58bgFY/4rjyXWcdtTZavfRF8+B9MugSqL0IfKaTh3WPENcCwTRiC1BzqLTGIFptrDaVb1eDZhtHbADqNKIkp+qDz82jAPqElVXEVqC0U32TnZacTE1cQrMrQeTlt5xBt2ueQTeDytqnhDgKQReBJOhZYqbGZixVtwWoS95SbKo1b1ssqWh+xLag9e9+GQhT3df5JSMh7hF8Rkm7k4DEg/fJoEugXiPKTLMbVDo9jiOOyxymEU8NrbPPEzeqrmrlLhVx/LCKeGqojizrkctKEnQeEZ1/RpWgywBpn4Fl0Fs3z6CbQ+e/6SohiVUo+iVxW9fYBNTnLMM6r6ieZZ+wqhMOq4jtQWlAXj+G4l6WDNXka9HI4e7NM+g/Q3//psv/GphHEHysdmX4EJS0b2rx4H0y6BqQV61RqbRbXyKLMI+LnKWyv02fDPoKdDJSKHZlu3DMR5RzNo7YBCT2n8kMMsgggwwyyKAvQn8AX63FfdoW7bcAAAAASUVORK5CYII=	\N	2026-03-31 17:13:21.247078	2026-03-31 17:13:29.844234	2026-04-07 17:13:21.247086	\N	\N	\N	\N	\N
591febe6-a663-4370-b5bf-1a670947afb2	6dfa30fb-50d8-492e-ad78-c785949b7e2d	106a34ff-4704-406c-9912-3b407e5417b0	2e56c1be-9aed-4c80-ba33-a7426fac672e	+79280037547	539e674d-584a-4279-9d35-74d40860916f	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	confirmed	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAAC8klEQVR4nO2cQcrjMAyFn8aBLm2YA/Qozs3Kf7P4KD1AIV4WHN4sbCdu/xmY0pmkbeRFSNp8VAYhy09yhXh4hB+PM4BCCimkkEIKKfSZkJTRQcTVxx6A9JgEiPWFfhPzFFof8iTJEeAQRTjAEMA03xmSJG+h9cxTaH0ozgHAJsCPkyC4m2gh0m1nnkKbQdLDsLqFITma7/vTN5uTQs9BsYOIW/xgkv/1Swq9IlRXAksAEQDsRRh6AREdOH/RRooXn5NCz0BoM0YYwo+/u9QXPEkOLz4nhZ6BskcsA7AJ5GjIwSbky91Qj/h8SHoA0kcR+LGoENLHsqQULcKV995kTgo9vWpwsDVQeJZAURYMm8ChihIaI/YDxQ7SYxIE6YBwTPljcjSUE9PG5im0HsTBJmQVIrj5MYrwyxnm5WRD8xTaYPcJQ/hzl4h4oMACAnvJ3zI4kwTRAX5Y1zyFVofajcRg6z7Uj4a5pOGZUNKKfKd5xIdDJUaEHigxIo+rNJJUcJd8w7XNU2h1qIkRgGUpZPgli0TJLAFLaozYCyTiSiEcAMAvtyhUzHVxNBWOt5iTQs/HCE82svWNHkGqHrETaPaIWbsGUPLJKmVnV4F6xC6goln6sagQpWnK3m09qkahecTHQ23tMy8YnBPIxUGgmeXeIF/LnkAUyXr26XygnHgVklfhELWrbg9QUSWBqUMQgOGYOgZnUBwEgMCOFNiLqB7x+VCTWS765JJUckBb9dDM8vOhHCOy0BDEUHLOECchYgfAjpCm/LGyeQqtDv2hh6rWMO6zTY0RO4GWM11AvIkHuUkidsg9E9uYp9A2e418poskEeTA1gVqHiH9NuYptD4U26NbcmLCklkiiHbM7Abq7p6ZC1rxZ4I/d0lKF40DEOda+YvPSaF/C8VDLnaWeuhc8VwObbzfnBR6HMrVzTrCsdbAw5GU5SzoVuYptBr0/UwXZyEq55PLjlTrGnuA2ua5vx36z2QKKaSQQgoppBAA/AKxFVUUKkGQZgAAAABJRU5ErkJggg==		2026-03-31 17:12:00.582125	2026-03-31 17:14:08.022252	2026-04-07 17:12:00.582131	\N	\N	\N	\N	\N
a4f91d90-2b7f-4444-ba4c-8229485e325f	6dfa30fb-50d8-492e-ad78-c785949b7e2d	5680937f-a565-4398-8cc4-9b17a7b54f06	aa3023e5-e7d8-4141-ad7a-71e18de1ad79	+79280037547	539e674d-584a-4279-9d35-74d40860916f	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	confirmed	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADA0lEQVR4nO2cS27bMBCGvykFeCkBORB1gxypZ+oNpKPkAAXEZQAJfxd8WEk3TR1YiTVcWZY+mIQG8/iHtIkPj/nHxxlwyCGHHHLIIYceE7IyOmxkMxtTB7AZs5nZmOoD4yHTc+j+UJQkLcA8tHvpIhv7FSBIkvQWut/0HLo/lIoDkJYg5gFs7F+NuIRsB2bWHTc9h+4Gde+uLU5bR5xAswUB2/tHvvyaHLoFev+6NRsIwGAzkZ5kn/JLDn0PqFpELyAB9L87YOuIvwYMAiIVK7n79Bw6CprNzGwA+/lykY3pIiCIuICNbLnUOGp6Dt0PQm8H9LXqoF/z3VKJtDF98TU5dAtU3/kCmgBpAUkrmvqVaiBB+TK6RTw6VHzE1F/dQ5AmQnYUxSwo9uIW8fhQjRoLZO0hZn9QDISoFU2EHDrcIh4faj6ihIk3icOarSR/ammFW8RDQy2zXCmOQiV0UGqN6jLiglvECaA3mWX2AmuWsvcGIukaOtwiHhrKCpVIYYXUYRBkEPJtzRZW5jGsRDWZ6ouvyaFboH3UmFqtkR1FzR5KCrG4jzgbFF86StuTIEgXlZrz5SIbj56eQ3eBdnlEcQBUFaIVHFXC9OrzDFDrdK1dbntGAaQOSE8rpCcxP6+dwPOIM0C1oCQUSSp/t1DTippRuIp9Ligum2lKXRarzYagsrtyALMBit84ZnoOHZNHlJKifLpqFPm5CVeozgC1vkZoASNor1gDNe/0qHEGaJ9HtF5W7m9pd9k6o24Rjw61F1/DRNkfodbNKM7De58ngf7eQwV7uXLnI/A84jzQ9UwX9Cr7LONLPdhF6koyccz0HDqg+szpJUXKpn+1LE/MQ0k0mYdQpezvsSaHbtIs0wDxF2Unfju8o/l565jfndj44mty6DOhrEZFrZTQ0VqhTZn4dmty6EZoy4fBAcjCZT4qXhXN77gmh/59XGWHuglfeUNd2ZDd5InJe5+ngLjWnEDYVZ9lN261DdpfBrhFPDRk/s9kDjnkkEMOOeTQf0J/ALrG05OF4xftAAAAAElFTkSuQmCC		2026-03-31 17:17:14.8179	2026-03-31 17:17:27.680795	2026-04-07 17:17:14.817906	\N	\N	\N	\N	\N
cca94961-cedb-4897-84d3-c86a9830f413	6dfa30fb-50d8-492e-ad78-c785949b7e2d	5680937f-a565-4398-8cc4-9b17a7b54f06	aa3023e5-e7d8-4141-ad7a-71e18de1ad79	+79280037547	539e674d-584a-4279-9d35-74d40860916f	\N	created	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADL0lEQVR4nO2cQW7bMBBF35QCvKSAHMBHoW4W9Ei9gXgUH6AAuTRAYbogKavNqq0jGdFwZ4sPHiLEaP4fMqL89Yjf/p4BgwwyyCCDDDLoa0LSxgBxBMgDwCLEcRHIfcJ0SHgG7QihqqoEVVVNTvsoAE4Bt3lQ580vviaDngHllgBkygMy5UvdFjr7UifUDHJUeAbtBg0fv1pE4S4aJyDchA8C9cXXZNBToTgCUQbkXQv6/VqQ6VN+yaCXhHqO8ApkIPwYkaBAHJMSEgqZ3xLFi6/JoCdAUURERqDWk3lA3m8DraxgqVLjqPAM2jtHbBJAvBbAF8DfReOItAxyRHgG7Q7VHSHhxwjgipIFjWNCoziVkN6KkNvT3cMzaHeo+hFVZAYtbKyIkNioT50B8yO+PrQ6VAWdqyX1GA/DSlXn9aPtiFNATmXyBZ39NmUQRxAZFwEWqyxPALUcUUvJ7lgTUssWWwM7OXOxTwCtdcTj5QDgVwN7rSM2748XX5NB/wM1rYFfug71iepHhIQSp4tStUYeu0p98TUZ9AQo3IYqJACQiS4uYBGRq9YuqEzHhGfQIS62RHFFYCjgy0CcgJDeCrAM9U2yd3gGHQlVKyLoXah+RO103UVELqpzthMzZ4Ba9RDFFchvpRsSy0CYnUK+qISZ1v3aOzyDdoe6+qz2U4GQ1kNTyWlTHYBqWoXJi6/JoP+BVlXZ/YiZ/tef6QZEsyxMfZ4B2rrYqmXdDPBID21eshxxBqhrjfzWbIc4rTVDvijgiuB/DoIvffKLr8mgZ0D+LjJ1K7t2MyYWkcnfpZUVNzt5eyYoX7Td0vB3ISQgjk4Jt4u2uxpXNYfqBNB6hqqgoNW7lvbdIhqvd6Gqz/mA8AzaHep9jTpc0SigrYfhVEJagNyMS/Msvz70550uVgna2hy+PQWsG34GqO+IBJsTEA8Juna/ukC1HXE2qMqM9djldxGpp6mo5/QPDs+gz4Y+3vLLQyEKSJidUu/yiFPIdhb7TJDX1cBepFUUeaDe6gkJ+v2eY8IzaDdo7XQBa+3Yjmb73vAIie5xWx3x1SGx/0xmkEEGGWSQQQb9I/QLNHBKLz20wzAAAAAASUVORK5CYII=		2026-03-31 17:25:25.012361	\N	2026-04-07 17:25:25.01237	\N	\N	\N	\N	\N
f4e946b0-fec9-47cf-9fca-c6095fedc69a	6dfa30fb-50d8-492e-ad78-c785949b7e2d	106a34ff-4704-406c-9912-3b407e5417b0	639104c6-8900-4de6-893c-3c537f738195	+79001234567	e4d68891-5966-42cf-9547-5b72c2c61e05	\N	created	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADEElEQVR4nO2czY3jOBCFv1oJ6KMEdAAOhc5gQ9qYOgMzFGcgHQ3QeHvgjzSeU+/M0F65dHDLbn1wCX4uPhaLNvHtI/71fQYccsghhxxyyKFjQlaOEVjN7LzWM5vvVs7MzM5PCc+h/lCQJC1AnAfBdDM7TxJhGQQMkiT9CPULz6F+0Fj+rjOEL7Cgu4n1U7DOKM5LvsBgSN3Dc+j5UJzBztPNiCeJcDX7Q+/k0EtC4+ML4esjpwcLVwOmNFr4elZ4DnWHqiImASsQ56GMEPEkLHx9yAD2lawXvyeHfgMUzcxsBsJSHuyf65ZA7nmq8azwHOqdI3YJIJ4SggRwN8VTomSQZ4TnUHeIPKsMCwCDdGGQLpPKmRbY/VeSdHnxe3LoV6CqiPxZJ2BK6MJQVTKVKWd5zRVxdIjytc8SGFpJCoBSnCIsg3TZLn7xe3LoV6D6IU9SyQftIeSUIUEeRFwR7wDtFFEsRHYPQ9HBppewuCLeAdr5iJIKanrQpV0TluIjXBHHh1A7HqxkcZHNYwYlzxFvAFVFtGFiyxGb5WRq2nBFHB1iW+XO3jF7zPq0uodUF8xdEUeHmiKalVyKLCQlcsoopSvwHHF8qDnLVHME1IlnrV7uBhHPEYeHmo+ArXC51R5qeaImD1fE4aEfKlTAw9CxuYdcq/JR4/DQfl0jTzMWmntgV5TwmuWbQPs+S/iQlZXvQbB+JoLAmBb2vXUvfk8O/SZI0s2IM8A6UpotzYyw3G1Xwvwf3ZND3z5aV10a91lgWlCcF1kQWDTIZ+HSNzyHukP7WWUrZecSZlvNyKseoZWp3EccGco5oqaHIYkVoHTnY3C37ChKu0Tf8Bx6FhRqUcLODLIzg6St83ZKEG18gPqF51B/aG2bOutT4ulmeSTJ9lLpEeoXnkNPhKZbGUPCdcTO68gmCzs/PTyH/jD0054u1k9ZnIH4tyCeikBUzETf8BzqDj3u6cpbNcLlPlq4jsmgbvqDoX94DnWHdv0R5L7ruga+LYnnXmx5D9VbQOa/TOaQQw455JBDDv1H6F8hUI24HnV8ZgAAAABJRU5ErkJggg==	\N	2026-03-31 17:27:44.333006	\N	2026-04-07 17:27:44.333011	\N	\N	\N	\N	\N
4e816b5d-5988-4927-be03-b4df8e5ef3f7	106a34ff-4704-406c-9912-3b407e5417b0	5680937f-a565-4398-8cc4-9b17a7b54f06	aa3023e5-e7d8-4141-ad7a-71e18de1ad79	+79280037547	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	confirmed	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADBklEQVR4nO2cS26jQBCGvxqQvMRSDuCjwM2iHGluAEfJDeilJdA/i37AJKvEEThQvcBg+ORqUapnt018eQx/vs6AQw455JBDDjl0TMjSqLEu1ECoAWZjMDPrQn6g20U8h7aHWknSCNBM6dZgF1kXzytJkv6HthPPoe2gOn2GK7R/QYSXyQCj1eoSgyrrypPPyaFHoPrDdVKGfq41WDUBs/3MLzn0O6CPGiHCFUElg9lEIz6pxJPPyaFHoKwRjYAAQDUxdOtnRIB1JevJ5+TQD0CDmZldwTrAXsdKtGMl60KNdcwx1dhLPIe2thErAzDc7kZMPK+YCLMlC7KHeA5tDhGzynYE9YA0pkPOQytJYyX1zZSy1P7J5+TQI1DUCPUArSZo49tPtYd4I51Vco04PpRthIo90ETSiEb5Mt9wjTg+9MlG0EhLCTNXKpPXSA8/+ZwcegQqNkIpXJAmpLFKsWQ7FvMwutc4ExRqoLmb2bWK3YwYXg63CYYrxMhyL/Ec2gzKjqC87nascggxLpcptnCvcXwoRwpNUotFN1YBBk32JO41TgMFM9r3i5JRoFL8LirDe411e4rn0GbQykbkNGMiFqditFmCyiUJcRtxZKjEEaVwmf1HevtNPizDNeLI0Dr77LMVyEXtSks92yPLk0DFa6TYMTY3elKGkd3JUrh0jTgH1L5fZF1zN6BKZ+0I0jjbaiHuTuI5tHkckWoPkGuW5UZueKQ+mNuIo0Ol7FBcQn77Sz07FyU8jjgPZK/jHPdrQHM3CBelJVXNhHUQLUg8+x1zcugxr5FH+m7MjYzS3wKPLE8ELXu6ogoMN8le3xeTUUcbsZN4Du2Qa5TwMo5gFssTw7XkoTuK59AufQ3rAL3d7hbXYsNs6vPmT2D2fZ8nhKyDuCrCunBJPa9Wkt5uvu/zDNDHPV0xzWj7uRYUXxFeJgj1pK3Fc2g3qFEqYMeSVLiIwUo8GRtfOQ/9LXNy6DsQS87J4iFKAzSWrnooKy49+zw4ZP7PZA455JBDDjnk0DehfxHOmBKvnO/0AAAAAElFTkSuQmCC		2026-03-31 17:50:36.953517	2026-03-31 17:50:49.162828	2026-04-07 17:50:36.953528	\N	\N	\N	\N	\N
c1aee370-4566-401a-a9f7-2c09d40c9e8f	106a34ff-4704-406c-9912-3b407e5417b0	6dfa30fb-50d8-492e-ad78-c785949b7e2d	639104c6-8900-4de6-893c-3c537f738195	+79280037547	19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	539e674d-584a-4279-9d35-74d40860916f	confirmed	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADCUlEQVR4nO2cS27bMBCGv78S4CUN5AA5Cn2DHinokXoD8Sg+QAFxaYDCdEFKUepsmqZybA0Xsl4fNIQH8+JIMv56pG9/z4BDDjnkkEMOOfSYkNrokY5AkqRT7oEs6ZTnG043Ec+hDaG+/sQBID9h6fvUA10BLrK6l7sCgLYWz6GbQXk2AHHszGwE6dgZ6flSL0jqbyeeQzeDmq8IFxHPPXo5H67z0zubk0P/DFXz0Mak//gkh74cNHuCYEAG0vNFxJ/CyJOArghgbSm++Jwc+gQoSappRqxuojOdWBsKSdJbaDvxHNraRqwNQCgYGSwdEenY0SzILcRzaHMIMzMjmhlxBAjLHmBDsFkbQrvPhi8+J4f+BZo1Yuysmoeh/vEFs7FbtKRgA53V4RrxyNBaI5ZSxOsFs1fdmE+4RuwDmkR6LugEQCiQ1LcN4aJ3oe3Ec2grqJmCAaibehhKu1p9xQjNjLiNeHRoqUeMiPCrV/z5VCAfjPR9RNEm1VwjHfHscwfQEkewLGl0LXoYeBNtEgoeRzw+NNcjMhgUgEnEAXRVwO5MdY30i8/Joc+AgllrgTh2BvlQgwkbAOK5h5WC3MmcHPoI1LwGzL6iZZrv1SNwr7ED6KpmGa0VKWtEUbOOsJxzjXh0aC5ELfHk62jxpK0NhWvEXqD0XCDpYDoxiXQEYFL1FT9W7RI3Ec+hrXMNEUCEXzV2VDz3RfF8MMWzINokIx8819gBtHITQAsq6x6hrWu0OMK9xq6g2l251K5DwYYskXQwYNLrEtjdzMmhj0BL9rmMUHi3PyKa24j9QCvXUbvqZg+hl7M0Z6RLeHkXc3LoM2zEEj2M68PWT+MdM3uCajvMCDbUiKKtkEOWmiexcjPxHLpBZNne6dLLuNQj5l46Um3Dnvy9zx1A/R/HRu6KCAC5L4o2ydIJID95HLED6E+NIJ06IAsI42c+yaH7gK7e6YJJ1RakU18sqTPF8anUQvfW4jm0OXSVa8TxbbPlvNw1t+17rvHgkPzLZA455JBDDjnk0Aeh30IJNScbNBqWAAAAAElFTkSuQmCC		2026-03-31 17:51:12.927347	2026-03-31 17:51:48.262998	2026-04-07 17:51:12.927353	\N	\N	\N	\N	\N
f9202e3e-65e5-4e56-a8cb-726b26652fd1	6dfa30fb-50d8-492e-ad78-c785949b7e2d	106a34ff-4704-406c-9912-3b407e5417b0	2e56c1be-9aed-4c80-ba33-a7426fac672e	+79280037547	539e674d-584a-4279-9d35-74d40860916f	539e674d-584a-4279-9d35-74d40860916f	confirmed	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADJ0lEQVR4nO2bXY7rNgxGDysDeVR2kKXYO+iSLrqkuwN7KVnAAPZjAAdfHyjZnkGL4nZaO3Doh0z8czAUzFDUR8rELx/Db7/OQEABBRRQQAEFdE7IytFgHU9juILZ8tFN9YHuEPMC2hFCkkQrSRqTIEtAEq1m1JP8xua5/sXHFNB3oKb8na7Q/tzeEdMVW04N0ry7eQEdDqmfzKQRzK5J6nnaP0L/6j8F9JpQ8+W8vP78MMgfBqTZPgePlx9TQP8FlCX1lLTC7Aq0Y5L6/HAnkTR/hfYzL6C9ocHM6rqigfZ+EUwN9uN+EfD0pcZR5gW096yxStmChzF4Tvk0yDPaPrCveQEdBFlXo4CZXcoi848reKBYRYnuEPMCOkCPGIsA4df6PEM7QrnmGkV5OPSIU0PlJcvVKHA1yj1C8m/qgeo04REnh+rPvrrAGhTU53L6KYyER5wc2r5uwGVr9wiN4B891EARHvEeUHnnWSrZw72B4SZZB9iPVYo4xLyAjqh0zR4PgFTSCs8tck0m1iNixJmh4hHkxQVI29pnmVMoEmZ4xJtAHh4Gu8g6L209TT1J1k1m4LnFjHWHmBfQAQrV1GBdfljtiihdNEBatKpQsd8BqrMGLHnEuq5YBKsaI2KtcX5ok0fUAmjaJJruJS5FjKFZvgNUK13TRcZkQB79Tp0i0mzD7WEabnNtpnjxMQX0HWgbI4psXfosPy1Bqx4Rs8bpofKzb382eLMlNOX1D12SAVh7b4D8ETHiDaD6kvPcaLgJY1l9kj+Mtn82QJqNqaltEi8+poC+A20VqtKJv9Wz1/XHKljFrPEGkG/VaDXX7hhvnyp1DS+KHmheQPsrVMueLlch2hG8MX+4AkwNuHB5iHkBHVHpksqeLpLWFpkaPNb1R8waJ4e+1rK2N/zaciE0y/eEfMLIknWuQqRaGb03fwvtZ15A/zf0dU+XmAAmQ4OBhltRJ7Ybu158TAF9B1r0CIE7A3XXbztesfZuaPi9aFW7mxfQ7tCm9knpk1lyzDyzZpul9zLyiLNDf7GnC+pOLrR8+7Sr68XHFFBAAQUUUEAB7QP9CXtrWc6iaDQzAAAAAElFTkSuQmCC		2026-03-31 17:52:31.412824	2026-03-31 17:52:38.249128	2026-04-07 17:52:31.412834	\N	\N	\N	\N	\N
0400a4db-8bed-471c-8337-16f12c554c73	6dfa30fb-50d8-492e-ad78-c785949b7e2d	5680937f-a565-4398-8cc4-9b17a7b54f06	aa3023e5-e7d8-4141-ad7a-71e18de1ad79	+79280037547	539e674d-584a-4279-9d35-74d40860916f	\N	created	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADB0lEQVR4nO2czW3jMBBG3ywF5CgBLsClUB2kpGBLcgdiKS4gAHU0QGH2QFJSsqess7IjDQ9JJPohJDKYn2/IiPLlEX59nQGDDDLIIIMMMmifkJTRAKMIjOUn6ecvIiLSP2R5Bm0IoaqqeFVVjU51aFXxmsCrKrR1Yvnc8OR7MugeqCnfxw78BcRfBWXsUMZT0tA3CQABlzZfnkGPh0IH0rcJwjkhb3qT//SbDHpKqPn8wl+67CMWbyH+8qjlGbQ5VC2iVWAsDzlChM4lwmuZWCtZT74ng74BCiIi0gHgFB9B3iLI27VBeqZcajxqeQZt7SNWDiCcb6KQgDah5fGj1v3kezLoHqhWnxEAp6oRdMAVG/DRfZi16nPvULEIWs1SRDGGrEKADm0pOfOE6RG7h6pFANU91JEVqmwgKU+YjzgKpBqdEs6q0gOQPcMk0N6qqI2rsz9iTwbd4yNUI9R0oRoIc5goqYblEUeAVhaR84jSw0g5hViCyNLcMIvYNbTKLEtdkR9Lp2sZOZkwizgONEm2g9BNkrPIAfIjMInq9cXyiANANWpoKnFhAPCaarkZSzFaKlLzEXuHaiAAVkVmzijmZGIpS02P2D006xGzXNmmWZdyOdHMLmMZZhF7hlZRo+SOcVG2Swmqw2wvZhG7h+ofuU1VhVhk63Y+bpftxXzEEaAPUWPxDKtuBlAchfmIA0E+TiL92KBDlq1fdBEuVT8drfsZezLobiic5x5Gm5A+v51EpFta4o9bnkGbQKvT+fVNjR8ANb2EImta1Ng7tK4q5zyiFBdZj6j2Mt/hMIvYNZRP1dUswSWFm6iPneAvJxV/FWA8JZjPVT37ngz6BigXmRFE5EWlx+WKlHAuQgWMDdI/ZnkGbZ9HRFgVnj6uZevySet9HhPy13qFw2tCf0tTzcJ8xCGgv+50ASikhtA7BSYhCGjo7d7nEaDPd7qU0SXC6zvidRKlfW803xOOp+2XZ9Dm0OosNtQDEeveZ80ySuvD8oi9Q2L/mcwggwwyyCCDDPpH6A9v8LDSY+QTmQAAAABJRU5ErkJggg==		2026-03-31 17:53:25.373993	\N	2026-04-07 17:53:25.373999	\N	\N	\N	\N	\N
ad97644c-3ff6-4bef-8703-801ee8311f1e	6dfa30fb-50d8-492e-ad78-c785949b7e2d	106a34ff-4704-406c-9912-3b407e5417b0	18da57a9-ac6c-425a-b82f-3e75e580ac91	jjjj	7192f426-cf48-402a-bf07-1df31e7c255f	\N	created	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAAC4ElEQVR4nO2cS26jQBRFz+tCyhBLvQAvpbyzqJfUO4CleAEtwbAl0O1BVUGRjJykbQceI1z4iEK+en9s4uaj/3E7Aw455JBDDjnk0D4hy0cD/Wk2u4wNMJbly3r2kO05dH8oSpIGIF5fBO1foz9LQJA6giRJW+h+23Po/tCYDYDZeQLGBuIA0E7pC8mCPGp7Dj0QGs2glehPQBxm+193cugZoebdSjsA4wni1VBvYPH3F9zJoe8BFUW0AkaA0SB2gv4siCJdqCtZT/5MDn0B1JuZ2QmIQxCMDfZ6bbDL2GAX5pRqPGp7Dt3bRlQGoD8FBNP247bW/eTP5NBnIFJWmfIKgtS1EymyhCBpCPVVSVL35M/k0GegoggpiSEVJbIYYM0+1UGuW7giDgLZ6/VF9GdJHbPZpdiIUpwKSrL4Rs/k0O1H9gQDJHsQJZWzieJEpvrLbiP2DFVeAwgiaioJB0H5rM2hhiti/xBrv6KOI9psHtY1rYcrYs9Q9UsTl5ghDizdr5J/uI04BlRsRGUPQsk60gWV3ucQ5LnG/qFNZAlVKPlGB0kbbiN2D9Veg9U5JP+xaoMkELcR+4dKaAA5w4jDphq1+hRp8jjiAFAVLryzESUFVddmx+KKOAokXRtgfFk6WrPRn8jJaBxmy8NVD9meQ4+oUC0xQ7v88FW5MriNOApU9T5Ln7MEkMvH5DWWjNQVsWtoo4gqolAlhqIXtxFHgGqvkSSQlpe+hpaZ/FaefR4AWmaogoAJgzBZXptNvQGxA4vdA7bn0N2hpIgyQBkm9RcAZhMEGe2fBsafEzA3uvf2HLo7VM9QVZ0L1qZo7To8jtg/VM9Z5lmIZYyuXSclqEqYroiDQWOTKtbEa4N+nfM01foi4Dd8JoduON7aiMpQlNo129eB3UbsGnobR5Tsk9zaWmcmlhlcV8SuoWqqjjxYWboZywsauR/qNctDQOb/TOaQQw455JBDDn0Q+gcRht2bCLD6eQAAAABJRU5ErkJggg==	\N	2026-04-01 12:09:34.516427	\N	2026-04-08 12:09:34.516433	\N	\N	\N	\N	\N
9cd5fd52-d088-44d5-a388-f8791b42842b	6dfa30fb-50d8-492e-ad78-c785949b7e2d	106a34ff-4704-406c-9912-3b407e5417b0	aa3023e5-e7d8-4141-ad7a-71e18de1ad79	hhh	7192f426-cf48-402a-bf07-1df31e7c255f	\N	created	iVBORw0KGgoAAAANSUhEUgAAAZoAAAGaAQAAAAAefbjOAAADFElEQVR4nO2cS27bMBCGvykFeEkBPoCPQt+gZ+qRcgPpKDlAAWopgMZ0wYfpZtM0huzIo0UMPT6YhAfz+GcUUT59zD8+z4BBBhlkkEEGGbRPSMoxwCwicl4GgIswjxeBpT5wfsjyDNoeCqqqGgF8AvwqzHJQWA4KOFVV1Vtou+UZtB00lM9lhPAGAgeF5agS4hFpDwq4tPnyDHo8FOJFwK+iv0Yg6Fpjxb2/yaCnhIaPl1wSAAl6EZ0FlOUO32TQ94DI+UHJI1zJFPJpThycEmLNI4Kq6vTkezLoDtAsIiIjEKJTWAZywREiAJdcajxqeQZtHTV6KduvotAKjlMC/K3W/eR7MugrUI0aEchFZnSqk1fVKdecif6uRY29Q3Q6QydK4P7ugOmEszzihSCf0GkZkHM+v0jJJ6NTgqZ8TacHLc+gjSGdcCrnLFcmdPJFjBI5rVKFy4ctz6DNo4ZOPlEcQE0m4BomvHYlqEWNXUNNoXIKPgLLkVxwzD9/Z4WK8C43MtWT78mgr0BULar6iBBdKT2ae8geRDVhPmL/UNfpkqCXQefRofMpDQqX9sfV7te07fIM2hzq9IgqQLRT32TrnHJWd2I+Ys9QjRoRCDl0tEZGhHIjOi0xxSxi79CNRcRiAiWt8DWP6JphZhF7h/qocW124lM99dp5C7OI/UOt1lC9dsNLc6M1MpptWNTYP9RcQckdS+EZyWlFbXKRa1PzEfuHWtQoTqHYQXUZvR4RzSJeCfKrEHQVoNQVcvZrGZEJ79cW2GOWZ9BmUJuqa30NX1wGra9RnrQ84iWgm8yy2kZVo5qy3W6YReweyip2HaB0SWdxKmEq2nW5sRwT3RTNk+/JoDtAocpUeUhiHgHyq36uViKLveX3ClA/Z5mzB5/6mQnt8gjrfb4mtByUWURKhbEMZB/RFRzfbk8G/fvx4Z2u8HZEQhzLi57zaRXC20HpZviffE8GfQWqFuEVWEDn0eUr9fd3Sh6fyunltsszaHPoJlOgqBB14rJ0QYuUbXnES0Bi/5nMIIMMMsgggwz6T+gPRJOfgLli8kUAAAAASUVORK5CYII=	\N	2026-04-01 12:48:45.50494	\N	2026-04-08 12:48:45.504949	\N	\N	\N	\N	\N
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.services (id, name, code, bonus_amount, is_active, created_at, clinic_id) FROM stdin;
aa3023e5-e7d8-4141-ad7a-71e18de1ad79	Компьютерная томография (КТ)	01	300.00	t	2026-03-31 06:37:45.240139	106a34ff-4704-406c-9912-3b407e5417b0
639104c6-8900-4de6-893c-3c537f738195	Рентген	02	100.00	t	2026-03-31 02:23:49.557007	106a34ff-4704-406c-9912-3b407e5417b0
18da57a9-ac6c-425a-b82f-3e75e580ac91	Эндоскопия общая	03	500.00	t	2026-03-31 02:23:49.557036	106a34ff-4704-406c-9912-3b407e5417b0
54b7f779-7e61-488e-a2cb-ed9726ebe6e0	Гастроскопия	04	200.00	t	2026-03-31 02:23:49.557033	106a34ff-4704-406c-9912-3b407e5417b0
03492f8b-b3e7-4203-8bb5-6249a7880f92	Колоноскопия	05	300.00	t	2026-03-31 02:23:49.557014	106a34ff-4704-406c-9912-3b407e5417b0
22580620-70ba-4ff9-bc4b-6c54eea9d20c	Кардиолог Пасаева	06	200.00	t	2026-03-31 02:23:49.557025	106a34ff-4704-406c-9912-3b407e5417b0
2e56c1be-9aed-4c80-ba33-a7426fac672e	ЛОР Сайдулаев	07	200.00	t	2026-03-31 02:23:49.557019	106a34ff-4704-406c-9912-3b407e5417b0
4cacacaf-4d03-4285-b8e5-25e2ae7a7b2b	УЗИ	08	200.00	t	2026-03-31 02:23:49.557031	106a34ff-4704-406c-9912-3b407e5417b0
2c4691c4-fee3-4919-a35e-366d761f8184	Уролог Давлатбиев	09	200.00	t	2026-03-31 02:23:49.557028	106a34ff-4704-406c-9912-3b407e5417b0
788e35e8-d5ca-40ae-a1bb-c16ce52664f1	ЛОР Куракаева	11	200.00	t	2026-03-31 18:57:52.30974	6dfa30fb-50d8-492e-ad78-c785949b7e2d
0d4060fb-f0c2-406b-8303-b28c9a6d91a5	Травматолог-ортопед Дуиев	10	200.00	f	2026-03-31 16:44:22.286333	106a34ff-4704-406c-9912-3b407e5417b0
31439613-3b94-4a3a-a351-d99921d9476d	Травматолог-ортопед Дуиев	15	200.00	t	2026-04-01 02:22:19.255774	106a34ff-4704-406c-9912-3b407e5417b0
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.system_settings (key, value, updated_at) FROM stdin;
commission_receiver_id	e4d68891-5966-42cf-9547-5b72c2c61e05	2026-03-31 06:19:58.832804
commission_rate	10.0	2026-03-31 07:00:28.703406
commission_enabled	false	2026-03-31 19:02:55.453893
mis_api_url	https://mis.example.com	2026-04-01 05:07:47.363066
telegram_notify_enabled	false	2026-04-01 05:07:47.37821
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: clinika
--

COPY public.users (id, telegram_id, full_name, phone_number, date_of_birth, role, clinic_id, is_active, created_at, username, password_hash, category) FROM stdin;
e4d68891-5966-42cf-9547-5b72c2c61e05	\N	Главный Администратор	\N	\N	MANAGER	\N	t	2026-03-31 02:42:10.168216	khamzat	cd0ffd8593d0e86a87c37802cbb7b378:0ce983a38d959ffc41b1d31d459e4ed50c4f9b3c8d42164ec643dba168279807	\N
19d23f3c-7ce0-48ee-aedd-fc867b2df8c8	\N	Тест	\N	\N	ADMIN	106a34ff-4704-406c-9912-3b407e5417b0	t	2026-03-31 17:08:24.050896	test	98947b0c52919aaf798981a3bf851509:44c9ec23fd9e4e5f3b5fce44a7d2df34a2d5d8c37aedc2f110cff035e9398440	\N
8fad3481-c5bb-4f4d-9953-e9d053296cb8	adm	Дузаева Иман Магомедовна	8(966)725-39-79	2008-03-20	ADMIN	6dfa30fb-50d8-492e-ad78-c785949b7e2d	t	2026-03-31 18:35:37.288766	i_duzaeva	e41d03fde2681fd2cc03b3741dde597d:9cff29d9d80fddebd31856d2f0a88d3fd417081ab4c89e0758094148a80947d7	\N
44881e4d-c244-4e71-9571-fe000d10f8df	a	Батукаева Хеда Руслановна	89388916440	2000-03-18	ADMIN	6dfa30fb-50d8-492e-ad78-c785949b7e2d	t	2026-03-31 18:25:31.244212	h_batukaeva	709c67f0bcee71d6da85825631cc82b2:ecbd214bbab7bebcc6d1f3b8669b123fff5402923e701a07a9743e880e6ffc39	\N
aeb083a4-5f30-4bc2-9ecb-18d3961dc285	admin	Атабаева Амина Зайндиевна	89958030102	1992-02-13	ADMIN	6dfa30fb-50d8-492e-ad78-c785949b7e2d	t	2026-03-31 18:15:07.650206	a_atabaeva	6ba1a88e786f4fb6acee614d81238ff7:0dc9f18131f197e868fbc86564947f414359a54f5c889d55356a501ad3dbaa10	\N
16642c90-3ccb-48c6-bc6a-aa56091f2c5d	admi	Мусаева Аята Ахмедовна	\N	\N	ADMIN	6dfa30fb-50d8-492e-ad78-c785949b7e2d	t	2026-03-31 18:38:20.855394	a_musaeva	345b4a7a9b3c17c8808c9acff6edd47a:a15027f86c51337096ba908b9668016be68d922e5a38bb2de8aca74f746e1fe9	\N
472e400d-e1db-4322-af73-fcfc82a57dac	adminn	Шаипов Сайдали Русланбекович	\N	\N	MANAGER	106a34ff-4704-406c-9912-3b407e5417b0	t	2026-03-31 18:48:36.216289	s_shaipov	ef8b8fd6ffc2d19c759143ae664c4252:14336275647df9e459049e12e445f767c671aa8a76396bd527c9a1ed3ceeaeb9	\N
7192f426-cf48-402a-bf07-1df31e7c255f	\N	Доулбиева Линда Сохруевна	\N	\N	MANAGER	6dfa30fb-50d8-492e-ad78-c785949b7e2d	t	2026-03-31 06:09:01.981768	lika	3aa8a7f00e7374fa5a0981a961553fb8:6545b342a2183e41b63d60ae6b7c60a0144832c858914c5d1fe8e417b49c0538	\N
60b18751-23ca-4657-87bd-fbe7a50220fc	al	Абубакарова Алят Исламовна	\N	2007-07-30	ADMIN	106a34ff-4704-406c-9912-3b407e5417b0	t	2026-04-01 12:05:03.157113	a_abubakarova	3f3e86b69c6a0a6c9b5ca06a1575fd31:c47ba4148d2a536c2d9b4b2c388155a0d935e6bbfbc141c2d5b1ad6fd9064751	\N
2021e4ef-423c-4483-835f-be991bddd16b	kaira	Кугаева Каира Анзоровна	\N	2005-12-23	ADMIN	106a34ff-4704-406c-9912-3b407e5417b0	t	2026-04-01 12:05:51.247776	\N	ac4173dbf6c1a08348e8326fe9f69c98:720e2a93a723fa44af67f9a3fd13bac848721e2def5acfacec381707b2cd1bc4	\N
533cf437-41b4-4d1e-a817-2b1a74ddab6e	khava	Ибуева Хава Майруддиевна	\N	\N	ADMIN	106a34ff-4704-406c-9912-3b407e5417b0	t	2026-04-01 12:07:15.795054	kh_ibueva	9b0bfb4fb595cb9fc19d9efbef7d3d92:27ff3998bc84eb7cd2b3cafb3527adf8eca0c7dcd2fe135be01ffb9176bb8802	\N
539e674d-584a-4279-9d35-74d40860916f	\N	Айза	+7 (928) 003-75-47	\N	ADMIN	6dfa30fb-50d8-492e-ad78-c785949b7e2d	t	2026-03-31 06:21:16.977768	aiza	851ae16966f5b40b5012ad7c141bf733:ca445e1d1814d11388d3d248fd59bdec24a183a525d2e27e8c81b7fd5ff58e59	doctor
\.


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: bonuses bonuses_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.bonuses
    ADD CONSTRAINT bonuses_pkey PRIMARY KEY (id);


--
-- Name: clinic_schedules clinic_schedules_clinic_id_day_of_week_key; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.clinic_schedules
    ADD CONSTRAINT clinic_schedules_clinic_id_day_of_week_key UNIQUE (clinic_id, day_of_week);


--
-- Name: clinic_schedules clinic_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.clinic_schedules
    ADD CONSTRAINT clinic_schedules_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: kpi_targets kpi_targets_admin_id_month_key; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.kpi_targets
    ADD CONSTRAINT kpi_targets_admin_id_month_key UNIQUE (admin_id, month);


--
-- Name: kpi_targets kpi_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.kpi_targets
    ADD CONSTRAINT kpi_targets_pkey PRIMARY KEY (id);


--
-- Name: referral_comments referral_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_pkey PRIMARY KEY (id);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: bonuses_referral_type_idx; Type: INDEX; Schema: public; Owner: clinika
--

CREATE UNIQUE INDEX bonuses_referral_type_idx ON public.bonuses USING btree (referral_id, bonus_type);


--
-- Name: ix_bonuses_admin_id; Type: INDEX; Schema: public; Owner: clinika
--

CREATE INDEX ix_bonuses_admin_id ON public.bonuses USING btree (admin_id);


--
-- Name: ix_referrals_patient_phone; Type: INDEX; Schema: public; Owner: clinika
--

CREATE INDEX ix_referrals_patient_phone ON public.referrals USING btree (patient_phone);


--
-- Name: ix_referrals_status; Type: INDEX; Schema: public; Owner: clinika
--

CREATE INDEX ix_referrals_status ON public.referrals USING btree (status);


--
-- Name: ix_users_phone_number; Type: INDEX; Schema: public; Owner: clinika
--

CREATE INDEX ix_users_phone_number ON public.users USING btree (phone_number);


--
-- Name: ix_users_telegram_id; Type: INDEX; Schema: public; Owner: clinika
--

CREATE UNIQUE INDEX ix_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: services_clinic_id_idx; Type: INDEX; Schema: public; Owner: clinika
--

CREATE INDEX services_clinic_id_idx ON public.services USING btree (clinic_id);


--
-- Name: activity_log activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bonuses bonuses_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.bonuses
    ADD CONSTRAINT bonuses_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id);


--
-- Name: bonuses bonuses_referral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.bonuses
    ADD CONSTRAINT bonuses_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.referrals(id);


--
-- Name: clinic_schedules clinic_schedules_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.clinic_schedules
    ADD CONSTRAINT clinic_schedules_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: kpi_targets kpi_targets_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.kpi_targets
    ADD CONSTRAINT kpi_targets_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referral_comments referral_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: referral_comments referral_comments_referral_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referral_comments
    ADD CONSTRAINT referral_comments_referral_id_fkey FOREIGN KEY (referral_id) REFERENCES public.referrals(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_cancelled_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_cancelled_by_id_fkey FOREIGN KEY (cancelled_by_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_confirmed_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_confirmed_by_admin_id_fkey FOREIGN KEY (confirmed_by_admin_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_created_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_created_by_admin_id_fkey FOREIGN KEY (created_by_admin_id) REFERENCES public.users(id);


--
-- Name: referrals referrals_from_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_from_clinic_id_fkey FOREIGN KEY (from_clinic_id) REFERENCES public.clinics(id);


--
-- Name: referrals referrals_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id);


--
-- Name: referrals referrals_to_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_to_clinic_id_fkey FOREIGN KEY (to_clinic_id) REFERENCES public.clinics(id);


--
-- Name: services services_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE SET NULL;


--
-- Name: users users_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: clinika
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- PostgreSQL database dump complete
--

\unrestrict Gr7vUXySSHTLxJxYSplZ5LIAI8PE5njkH5yJrCYa0nYhYzy4zieAUxrUQSu319f

